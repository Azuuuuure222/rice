## Universal -

- Important terms + definations + images + diagrams + flowcharts + charts + data + timeline + maps 
- Anticipated questions & its answers
- Theme 
- Summary
- PYQs & its answers
- Sample paper & its answers
- HOTS/Compitency based questions & its answers
- Previous year papers & its answers
- Key concepets
- 
## Subject Specific -

- Character Sketch
- Formulas
- 

## Practice -

- Writing practice (eg letter, qna) & its answers
- Revision & its answers
- 

## Review -

- Practice like you are giving a test (3 hour straight doing a paper)
- Examine mistakes, correct them, note that question for later reviewal with what was wrong
- 

## Probably -

- Weightage
- AI made detailed notes for quick revision
- Use Anki flashcards