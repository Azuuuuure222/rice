# Notes Rulebook

## Universal Rules

* Notes must help to **recall, understand, apply, and answer**, not merely recognize information.
* Prefer **keywords, phrases, tables, diagrams, flowcharts, timelines, maps, and structured explanations** over long paragraphs.
* Every chapter must contain (may vary subject to subject):
  * Key concepts
  * Important terms + definitions
  * Important facts/data
  * Diagrams/images
  * Flowcharts/processes
  * Tables/comparisons
  * Themes/main ideas
  * Summary
  * Important questions
  * Formulae
  * Dates/facts
  * Answer structures

---

## Understanding

* For every concept, answer:
  * What is it?
  * How does it work?
  * Why does it happen?
  * What causes it?
  * What are its effects/consequences?
  * Where/how is it used?
* Connect related concepts rather than keeping isolated facts.
* Use:
  * Cause → effect
  * Problem → solution
  * Process → result
  * Concept → example
  * Compare → contrast
  * Part → function
* Convert complicated explanations into **steps, diagrams, tables, or flowcharts** wherever possible.
* Include examples when they improve understanding.

---

## Question Bank & Practice

* Maintain a separate question bank for each chapter.
* Convert important information into questions.
* Include:
  * Textbook questions
  * PYQs
  * Previous-year papers
  * Sample-paper questions
  * HOTS questions
  * Competency-based questions
  * Important/anticipated questions
  * Questions previously answered incorrectly
  * Direct questions
  * "Explain why" questions
  * "How/what/when" questions
  * Compare/contrast questions
  * Application questions
  * HOTS questions
  * Competency-based questions
  * PYQs
  * Writing practice

* Do not write only the question; keep the **correct answer/answer points** available for checking.
* Record difficult questions separately for later review.
* Occasionally practise as an actual examination:
  * Full syllabus where appropriate
  * Timed
  * No notes

---

# Subject-Specific Rules

## Science

### Physics

* Concepts
* Formulae
* Meaning of variables
* SI units
* Conditions of use
* Rearrangement of formulae
* Derivations where required
* Diagrams
* Representative solved examples
* Numerical/application questions
* Common mistakes

### Chemistry

* Definitions
* Concepts
* Chemical equations/reactions
* Properties
* Conditions
* Observations
* Trends
* Exceptions
* Comparisons
* Examples
* Application questions

### Biology

* Definitions
* Processes
* Functions
* Structures
* Diagrams
* Labelling
* Flowcharts
* Cause/effect relationships
* Differences/comparisons
* Key terminology
* Application questions
* Diagram reproduction from memory

---

## Mathematics

* Formulae
* Identities
* Properties/theorems
* Conditions/restrictions
* Standard methods
* Question-type recognition
* Representative worked examples
* Large quantity of independent practice
* Mixed questions
* Timed questions
* Error log

### For every important method, know:

* How to recognize the question type
* Which method/formula applies
* The sequence of steps
* Why the method works where relevant
* Common traps/mistakes

### Mathematics notes should prioritize:

**Formula → Method → Example → Practice → Error correction**

Do not spend excessive time making elaborate theory notes when the material is better learned through solving.

---

## SST

### History

* Timeline
* Events
* Dates/periods where relevant
* Causes
* Main events
* Consequences
* Significance
* Important people
* Important terms
* Comparisons
* PYQs

### Geography

* Definitions
* Characteristics
* Causes
* Effects
* Processes
* Examples/case studies
* Data
* Maps
* Diagrams
* Comparisons
* Map practice

### Civics

* Definitions
* Features
* Institutions
* Functions
* Powers/responsibilities
* Importance
* Examples
* Comparisons
* Application questions

### Economics

* Definitions
* Core concepts
* Mechanisms/processes
* Factors
* Effects
* Examples
* Data/graphs
* Comparisons
* Application questions

### SST chapter rule

Every chapter should be reducible to a **one/two-page revision structure** containing the essential facts, relationships, terminology, visuals, and likely question areas.

---

## English

### Literature

* Plot/content
* Characters
* Character traits
* Evidence/examples
* Themes
* Central ideas
* Literary devices
* Important events
* Important relationships
* Possible questions
* Answer frameworks

### Character Sketch

Use:

**Trait → Evidence/event → Explanation**

Do not memorize entire model answers when a set of strong points can be recombined into different questions.

### Grammar

* Rule
* Example
* Exceptions
* Practice
* Common mistakes
* Error correction

Treat grammar practice similarly to mathematics: **rule → application → correction → repetition**.

### Writing

* Format
* Structure
* Required components
* Useful language where appropriate
* Common errors
* Timed writing practice
* Self-correction

---

## Hindi

### Literature

* कथा/कविता का सार
* मुख्य विचार
* पात्र
* चरित्र-चित्रण
* घटनाएँ
* भाव/संदेश
* महत्वपूर्ण शब्द/पंक्तियों का अर्थ
* साहित्यिक विशेषताएँ जहाँ आवश्यक हों
* प्रश्नोत्तर
* उत्तर-बिंदु

### Grammar

* नियम
* उदाहरण
* अपवाद
* अभ्यास
* सामान्य गलतियाँ
* Error correction

### Writing

* Format
* Structure
* आवश्यक तत्व
* भाषा/शब्दावली
* Timed practice
* Error correction

---

## IT

### Theory

* Definitions
* Concepts
* Terminology
* Features
* Procedures
* Advantages/disadvantages
* Examples
* Comparisons
* Important questions

### Practical

* Procedure
* Steps
* Expected output/result
* Important commands/tools where relevant
* Common errors
* Troubleshooting
* Practical repetition

Do not rely on reading a practical procedure alone; practise performing or reproducing it.

---

# Memory Tools

## Flashcards / Anki

Use primarily for information that benefits from **short, repeated retrieval**:

* Definitions
* Formulae
* Dates
* Terminology
* Facts
* Names
* Vocabulary
* Grammar rules
* Exceptions
* Classifications

Do not turn long explanations or entire answers into cards unnecessarily.

---

## AI

Use AI as a **study assistant**, not as an unquestioned source.

Use it to:

* Explain difficult concepts
* Generate practice questions
* Generate quizzes
* Produce alternative explanations
* Identify gaps
* Create comparisons
* Convert verified notes into flashcards
* Analyse mistakes
* Generate additional practice

Verify AI-generated factual content against the prescribed material where accuracy matters.

---

## Note Quality Rules

A good note must satisfy at least one of these purposes:

**Understand → Remember → Retrieve → Apply → Answer**

If a piece of information serves none of these purposes, it probably does not belong in the notes.

### Avoid:

* Copying entire textbook paragraphs
* Memorizing complete answers when answer structures are sufficient
* Making notes so large that revision becomes impractical

### Prefer:

* Keywords
* Hierarchies
* Tables
* Diagrams
* Flowcharts
* Timelines
* Maps
* Formulae
* Examples
* Question prompts
* Answer frameworks
* Error-based notes
