#!/bin/sh

pipewire >/dev/null 2>&1 &
wireplumber >/dev/null 2>&1 &
exec dwl >/dev/null
