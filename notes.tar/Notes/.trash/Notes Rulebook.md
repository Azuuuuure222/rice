## Universal Rules

* Notes must help to **recall, understand, apply, and answer**, not merely recognize information.
* Prefer **keywords, phrases, tables, diagrams, flowcharts, timelines, maps, and structured explanations** over long paragraphs.
* Every chapter must contain:
  * Key concepts
  * Important terms + definitions
  * Important facts/data
  * Diagrams/images
  * Flowcharts/processes
  * Tables/comparisons
  * Themes/main ideas
  * Summary
  * Important questions

---

## Understanding

* For every concept, answer:
  * What is it?
  * How does it work?
  * Why does it happen?
  * What causes it?
  * What are its effects/consequences?
  * Where/how is it used?
* Connect related concepts rather than keeping isolated facts.
* Use:
  * Cause → effect
  * Problem → solution
  * Process → result
  * Concept → example
  * Compare → contrast
  * Part → function
* Convert complicated explanations into **steps, diagrams, tables, or flowcharts** wherever possible.
* Include examples when they improve understanding.

---
